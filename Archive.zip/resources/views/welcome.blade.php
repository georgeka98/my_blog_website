<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>George Karabassis</title>

        <!-- favicon -->
        <link rel="shortcut icon" href="{{{ asset('images/gk-logo-b.png') }}}">

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet" type="text/css">
        <link href="//maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">

        <!-- Styles -->

        <!-- loader -->

        <link href="{{ asset('css/app.css') }}" rel="stylesheet">

        <style>
            html, body {
                background-color: #fff;
                color: #636b6f;
                font-family: 'Nunito', sans-serif;
                font-weight: 200;
                height: 100vh;
                margin: 0;
            }

            .full-height {
                height: 100vh;
            }

            .flex-center {
                align-items: center;
                display: flex;
                justify-content: center;
            }

            .position-ref {
                position: relative;
            }

            .top-right {
                position: absolute;
                right: 10px;
                top: 18px;
            }

            .content {
                text-align: center;
            }

            .title {
                font-size: 84px;
            }

            .links > a {
                color: #636b6f;
                padding: 0 25px;
                font-size: 13px;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
            }

            .m-b-md {
                margin-bottom: 30px;
            }

            @font-face {
                font-family: DalekPinpointBold;
                src: url("{{ asset('fonts/DalekPinpointBold.ttf') }}");
                font-weight: normal;
            }
        </style>
    </head>
    <body>

        <div id="loader">
			<div class="center" id="loader-ul">
				<div></div>
				<div></div>
				<div></div>
				<div></div>
				<div></div>
				<div></div>
				<div></div>
			</div>
        </div>

        <div id="mobile_side">
            <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
            <div class="brand">
                <img class="navbar-brand navbar-brand-sidebar" src="/images/gk-logo-w.png"/>
            </div>
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a href="#" class="nav-link">HOME</a>
                </li>
                <li class="nav-item">
                    <a href="#" class="nav-link">ABOUT ME</a>
                </li>
                <li class="nav-item">
                    <a href="#" class="nav-link">PORTFOLIO</a>
                </li>
                <li class="nav-item">
                    <a href="#" class="nav-link">BLOG</a>
                </li>
                <li class="nav-item">
                    <a href="#" class="nav-link">RESUME</a>
                </li>
                <li class="nav-item">
                    <a href="#" class="nav-link">CONTACT</a>
                </li>
            </ul>
        </div>

        <div class="intro-section row">
            <canvas class="pg-canvas"></canvas>
            <div class="content">
                <nav class="navbar navbar-expand-xs navbar-expand-sm navbar-expand-md navbar-expand-lg navbar-dark">
                    <!-- <a href="#" class="navbar-brand">Academind</a> -->
                    <a href="/"><img class="navbar-brand" src="/images/gk-logo-w.png"/></a>
                    <button class="navbar-toggler" data-toggle="collapse" data-target="#navbarMenu">
                        <span class="navbar-toggler-icon" onclick="openNav()"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarMenu">
                        <ul class="navbar-nav">
                            <li class="nav-item">
                                <a href="#" class="nav-link">HOME</a>
                            </li>
                            <li class="nav-item">
                                <a href="#" class="nav-link">ABOUT ME</a>
                            </li>
                            <li class="nav-item">
                                <a href="#" class="nav-link">PORTFOLIO</a>
                            </li>
                            <li class="nav-item">
                                <a href="#" class="nav-link">BLOG</a>
                            </li>
                            <li class="nav-item">
                                <a href="#" class="nav-link">RESUME</a>
                            </li>
                            <li class="nav-item">
                                <a href="#" class="nav-link">CONTACT</a>
                            </li>
                        </ul>
                    </div>
                </nav>
                <div class="who-am-i row">
                    <div class="who-am-i-inner container col-xs-12 align-middle">
                        <div class="who-am-i-wrap">
                            <h6>Hi stranger, I'm</h6>
                            <h1>George Karabassis</h1>
                            <h6>Thank you for stopping by! </h6>
                            <ul class="social">
                                <li>
                                    <a href="https://www.linkedin.com/in/george-karabassis-60487b156/" target="_blank" class="linkedin">
                                        <img src="/images/soc-med/linkedin.png" alt="">
                                    </a>
                                </li>
                                <li>
                                    <a href="https://www.behance.net/georgek98171b0" target="_blank" class="behance">
                                        <img src="/images/soc-med/behance.png" alt="">
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="about-section jumbotron">
            <h1>Get to know me!</h1>
            <p>I'm a half Greek, British student, currently living in Edinburgh, UK. I was born in London, UK from Greek parents. At 4, me and my parents moved back to Athens, Greece to be closer to my rest of my family members, where I stayed for 13 years, untill we moved back to the UK to finish my education and study at a top and prestigious university which happened to be in the University Of Edinburgh due to my attraction and love for the Scottish culture. 
            <p>My current path specializes on using Artificial Intelligence and Machine Learning to battle cybersecurity, crimes and improve security systems allowing them to "teach themselves" to detext and fix new exploits, my current undergraduate degree in Computer Science and Artificial intelligence, will allow me to follow the right route and open the doors to complete my Masters degree hopefully at a top university in the US, together with my PHD. After that stage, I am willing to make a startup and accomplish my dreams.</p>
            <p>Of course, I love being a multiactive person. By having done multiple sports including Athletics, Swimming, Tennis, taking part into projects, such as <a href="#">HypEd</a>, a student lead project based at the University of Edinburgh and taking part into multiple volunteering position, such as being a class representative in my 2nd year Informatics class, a school comeete, helping staff to improve teaching by providing tips based on students' feedback and spending the remaining of my time playing the guitar and being surrounded with people I love, shows how much I enjoy my life and putting the effort to accomplish great things to master whatever activity I enjoy doing, based on what I was given. Finally, I am always looking forward to discover new things and activities and ensuring every day, I have learned new things!</p>
            <p>In the future, I am looking forward to continue improving myself, based on all the mistakes I do. My ultimate goal is to become an enterprenuer to run a company which will give benefits to the society.</p>
            <p>Drop me a <a href="mailto:georgek981@yahoo.com">message</a>, if you love my journey and what I'm doing!</p>
        </div>

        <div class="about-section jumbotron">
            <h1>Portfolio</h1>
            <p>Working on numerus projects, allowed me to expand my horizons and discover new areas which I never thought I would enjoy. I participated in many team projects, with purpose to develop my communication and team-working skills, but also solo projects, with goal to improve my skills.</p>
            <h3>Team projects</h3>
            <div class="container group-projects">
                <div class="row">
                    <div class="project col-md-4 col-lg-4 col-xl-4">
                        <div class="project-inner">
                            <a href="#">
                                <img src="{{ asset('images/hyped.jpeg') }}" alt="Hyped">
                                <div class="overlay entry-content flex flex-column align-items-center justify-content-center">
                                    <div class="annotation">
                                        <p>A student sosciety - lead project based at the University of Edinburgh focusing on the development of Hyperloop.</p>
                                        <p class="see-more">Click me to learn more!</p>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="project col-md-4 col-lg-4 col-xl-4">
                        <div class="project-inner">
                            <a href="#">
                                <img src="{{ asset('images/augement-bionics.png') }}" alt="Hyped">
                                <div class="overlay entry-content flex flex-column align-items-center justify-content-center">
                                    <div class="annotation">
                                        <p>A student lead project based at the University of Edinburgh focusing on the development of very cheap prosthesis for amputees.</p>
                                        <p class="see-more">Click me to learn more!</p>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="project col-md-4 col-lg-4 col-xl-4ol">
                        <div class="project-inner">
                            <a href="#">
                                <img src="{{ asset('images/cabochon-games.jpg') }}" alt="Hyped">
                                <div class="overlay entry-content flex flex-column align-items-center justify-content-center">
                                    <div class="annotation">
                                        <p>An online project with volunteers from all around the globe, focusing on developing a galactic-type game.</p>
                                        <p class="see-more">Click me to learn more!</p>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="hit-me-up-section jumbotron">
            <h2>Do I fit in your needs and wanna create something amazing together? Let's turn the burning idea into reality by dropping me a wee <a href="mailto:georgek981@yahoo.com">message</a>!
        </div>

        <script src="{{ asset('js/loader.js') }}"></script>

        <script>
            if (!window._EXAMPLE_HTML_) {
                window._EXAMPLE_HTML_ = true;
                stop();
            }
        </script>

        <!-- <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN"
            crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q"
            crossorigin="anonymous"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl"
            crossorigin="anonymous"></script> -->
        <script src="{{ asset('js/network_anim.js') }}"></script>
        <script src="{{ asset('js/script.js') }}"></script>
    </body>

    <footer>
        <div class="jumbotron footer">
            <div class="f-content">
                <h1>“You are a failure if you fail and you stop trying. However, making combacks after failures are steps closer to success“</h1>
                <div class="brand">
                    <img class="navbar-brand navbar-brand-sidebar" src="/images/gk-logo-w.png"/>
                </div>
                <nav class="navbar navbar-expand-xs navbar-expand-sm navbar-expand-md navbar-expand-lg navbar-dark">
                    <ul class="footer-nav navbar-nav">
                        <li class="nav-item">
                            <a href="#" class="nav-link">HOME</a>
                        </li>
                        <li class="nav-item">
                            <a href="#" class="nav-link">ABOUT ME</a>
                        </li>
                        <li class="nav-item">
                            <a href="#" class="nav-link">PORTFOLIO</a>
                        </li>
                        <li class="nav-item">
                            <a href="#" class="nav-link">BLOG</a>
                        </li>
                        <li class="nav-item">
                            <a href="#" class="nav-link">RESUME</a>
                        </li>
                        <li class="nav-item">
                            <a href="#" class="nav-link">CONTACT</a>
                        </li>
                    </ul>
                </nav>
                <ul class="social">
                    <li>
                        <a href="https://www.linkedin.com/in/george-karabassis-60487b156/" target="_blank" class="linkedin">
                            <img src="/images/soc-med/linkedin.png" alt="">
                        </a>
                    </li><li>
                        <a href="https://www.behance.net/georgek98171b0" target="_blank" class="behance">
                            <img src="/images/soc-med/behance.png" alt="">
                        </a>
                    </li>
                </ul>
                <p class="copyright">© 2018 George Karabassis. All rights reserved.</p>
            </div>
        </div>
    </footer>
</html>
