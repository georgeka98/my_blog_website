function openNav() {
    document.getElementById("mobile_side").style.width = "250px";
}

function closeNav() {
    document.getElementById("mobile_side").style.width = "0";
}

window.addEventListener("resize", function(){
    if(window.innerWidth > 576){
        document.getElementById("mobile_side").style.width = "0";
    }
}, false);

window.addEventListener('load', function(){
    appear_effect();
}, false)

function appear_effect(){
    var group_projects = document.getElementsByClassName('group-projects')[0];

    var boundings = array();

    boundings.push(group_projects.getBoundingClientRect());

    if(bounding.top - document.documentElement.clientHeight < -(group_projects.offsetHeight/3)){
        group_projects.style.marginTop = "0px";
        group_projects.style.opacity = "1.0";
    }
    else{
        window.addEventListener("scroll", function(){

            var bounding = group_projects.getBoundingClientRect();
            console.log(bounding.top - document.documentElement.clientHeight, -(group_projects.offsetHeight/3))
    
            if(bounding.top - document.documentElement.clientHeight < -(group_projects.offsetHeight/3)){
                group_projects.style.marginTop = "0px";
                group_projects.style.opacity = "1.0";
            }
        }, false);
    }
}